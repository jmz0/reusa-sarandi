# # Reusa Sarandi

Plataforma web para intermedia��o de doa��es de m�veis e objetos reutiliz�veis no munic�pio de Sarandi/PR, com foco na redu��o do descarte irregular e incentivo � economia circular.

---

## Tecnologias utilizadas:

- React;
- TypeScript;
- TailwindCSS;
- React Router DOM;
- LocalStorage (simula��o de backend);

---

##  Funcionalidades:

- Cadastro de usu�rios;
- Login e autentica��o;
- Cadastro de itens com imagens;
- Filtros e busca de itens;
- Sistema de interesse em itens;
- Chat entre doador e receptor;
- Caixa de entrada com mensagens;
- Controle de status do item (dispon�vel, em negocia��o, doado);
- Perfil de usu�rio com foto;
- Modo administrador (visualiza��o).

---

##  Arquitetura:

A aplica��o foi desenvolvida como Single Page Application, com separa��o em:

- Pages (interfaces);
- Context (autentica��o);
- Types (modelos de dados);
- Componentes reutiliz�veis;

Persist�ncia realizada via LocalStorage para simula��o de backend (n�vel prot�tipo): esta vers�o utiliza armazenamento local e n�o possui backend real. A estrutura foi projetada para futura integra��o com APIs e banco de dados.  
---

## Como executar

```bash
npm install
npm run dev
